window.addEventListener('DOMContentLoaded', () => {
  console.log('Baha Concrete ERP Desktop Electron Preload Initialized');
});
