import { app, BrowserWindow } from "electron";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";
import waitOn from "wait-on";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let serverProcess;

async function startServer() {

  serverProcess = spawn(
    process.execPath,
    [path.join(__dirname, "../dist/server.cjs")],
    {
      stdio: "inherit"
    }
  );

  await waitOn({
    resources: ["http://127.0.0.1:3000"],
    timeout: 30000
  });

}

async function createWindow() {

  await startServer();

  const win = new BrowserWindow({
    width: 1400,
    height: 900,
    icon: path.join(__dirname, "../build/icon.ico"),
    autoHideMenuBar: true,

    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  await win.loadURL("http://127.0.0.1:3000");

}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {

  if (serverProcess) {
    serverProcess.kill();
  }

  if (process.platform !== "darwin") {
    app.quit();
  }

});